export default function ImageCard({ photo, onDownload }) {
  return (
    <figure className="card-img">
      <img src={photo.urls.small} alt={photo.alt_description || photo.user?.name} loading="lazy" />
      <figcaption className="overlay">
        <span className="badge">{photo.user?.name}</span>
        <div className="actions">
          <a className="icon-btn" href={photo.links.html} target="_blank" rel="noreferrer">View</a>
          <button className="icon-btn" onClick={() => onDownload(photo)}>Download</button>
        </div>
      </figcaption>
    </figure>
  );
}