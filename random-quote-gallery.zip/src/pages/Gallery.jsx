import { useEffect, useState } from "react";
import ImageCard from "../components/ImageCard.jsx";

const ACCESS_KEY = import.meta.env.VITE_UNSPLASH_ACCESS_KEY;

export default function Gallery() {
  const [query, setQuery] = useState("nature");
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function fetchPhotos(search) {
    try {
      setError("");
      setLoading(true);
      const res = await fetch(`https://api.unsplash.com/search/photos?query=${search}&per_page=30`, {
        headers: { Authorization: `Client-ID ${ACCESS_KEY}` }
      });
      if (!res.ok) throw new Error("Failed to fetch images");
      const data = await res.json();
      setPhotos(data.results || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { fetchPhotos(query); }, [query]);

  async function handleDownload(photo) {
    const res = await fetch(`${photo.links.download_location}?client_id=${ACCESS_KEY}`);
    if (!res.ok) return;
    const imgRes = await fetch(photo.urls.full);
    const blob = await imgRes.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${photo.id}.jpg`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <section>
      <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search images" />
      {loading && <p>Loading…</p>}
      {error && <p className="error">{error}</p>}
      <div className="grid">
        {photos.map(photo => (
          <ImageCard key={photo.id} photo={photo} onDownload={handleDownload} />
        ))}
      </div>
    </section>
  );
}