import { useEffect, useState } from "react";

export default function Quote() {
  const [quote, setQuote] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function fetchQuote() {
    try {
      setError("");
      setLoading(true);
      const res = await fetch("https://api.quotable.io/random");
      if (!res.ok) throw new Error("Failed to fetch quote");
      const data = await res.json();
      setQuote({ content: data.content, author: data.author });
    } catch (err) {
      setError(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { fetchQuote(); }, []);

  return (
    <section className="card">
      <h2>🎭 Random Quote Generator</h2>
      {error && <p className="error">{error}</p>}
      {loading ? <p>Loading…</p> : quote ? (
        <blockquote>“{quote.content}” — {quote.author}</blockquote>
      ) : <p>No quote yet.</p>}
      <button onClick={fetchQuote} disabled={loading}>New Quote</button>
    </section>
  );
}