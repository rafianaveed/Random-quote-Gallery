import { NavLink, Routes, Route } from "react-router-dom";
import Quote from "./pages/Quote.jsx";
import Gallery from "./pages/Gallery.jsx";

export default function App() {
  return (
    <div className="app">
      <header className="header">
        <h1>🎭 Random Quote & Image Gallery</h1>
        <nav className="nav">
          <NavLink to="/" end className={({ isActive }) => isActive ? "link active" : "link"}>Quote</NavLink>
          <NavLink to="/gallery" className={({ isActive }) => isActive ? "link active" : "link"}>Gallery</NavLink>
        </nav>
      </header>
      <main className="main">
        <Routes>
          <Route path="/" element={<Quote />} />
          <Route path="/gallery" element={<Gallery />} />
        </Routes>
      </main>
      <footer className="footer">
        <p>Built with React + Vite • <a href="https://unsplash.com" target="_blank" rel="noreferrer">Unsplash</a> API</p>
      </footer>
    </div>
  );
}